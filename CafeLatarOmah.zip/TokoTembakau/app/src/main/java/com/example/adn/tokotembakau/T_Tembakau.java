package com.example.adn.tokotembakau;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class T_Tembakau extends AppCompatActivity {

    EditText nama;
    TextView tOrder;
    TextView qty;

    Button btorder;
    Button btplus;
    Button btmin;
    CheckBox wCream;
    CheckBox sberry;

    int quantity=0;
    int total = 5000;
    int totalfinal = 0;
    String name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t__tembakau);

        nama = (EditText) findViewById(R.id.nama);
        btorder = (Button) findViewById(R.id.btorder);
        btplus = (Button) findViewById(R.id.btplus);
        btmin = (Button) findViewById(R.id.btmin);
        btmin = (Button) findViewById(R.id.btmin);
        wCream = (CheckBox) findViewById(R.id.wCream);
        sberry = (CheckBox) findViewById(R.id.sberry);
        tOrder = (TextView) findViewById(R.id.tOrder);
        qty = (TextView) findViewById(R.id.qty);
        View view;




        btorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name = String.valueOf(nama.getText());
                Toast.makeText(T_Tembakau.this,"Order successful by "+name, Toast.LENGTH_LONG).show();

            }
        });

        btmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(quantity > 0){
                    quantity= quantity - 1;
                    totalfinal = total * quantity ;
                    
                }
                else{

                }
                qty.setText(String.valueOf(quantity));
                tOrder.setText(String.valueOf(totalfinal));
            }
        });

        btplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                quantity = quantity + 1;
                qty.setText(String.valueOf(quantity));
                totalfinal = total * quantity ;
                tOrder.setText(String.valueOf(totalfinal));
            }
        });







    }

    public void onCheckboxClicked(View view) {
        // Is the view now checked?
        boolean checked = ((CheckBox) view).isChecked();

        // Check which checkbox was clicked
        switch(view.getId()) {
            case R.id.sberry:
                if (checked)
                    total = total + 500;
                // Put some meat on the sandwich
            else
                // Remove the meat
                break;
            case R.id.wCream:
                if (checked)
                    total = total + 700;
                // Cheese me
            else
                // I'm lactose intolerant
                break;
            // TODO: Veggie sandwich
        }
    }
}
